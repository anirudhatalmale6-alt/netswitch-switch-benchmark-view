AI2ORBIT SETUP PACK - 24.10.2026

docs/                    End report and setup instructions: PDF, TXT, DOCX; inventory: XLSX
pages-netswitch/         The web suite, every page - put on any static web host, or open menu.html
pages-football-ai-3d/    FootballAI site - open play.html
switch9/                 (full pack only) Switch 9 native C++ engine: source, Windows / Linux / Android builds, README
footballai-android/      (full pack only) FootballAI Android app 1.2.0: APK to install, AAB for Google Play

Start with docs/AI2Orbit-End-Report.pdf - Setup 1 to 8.

Copyright AI2Orbit All Rights Reserved 2026.
