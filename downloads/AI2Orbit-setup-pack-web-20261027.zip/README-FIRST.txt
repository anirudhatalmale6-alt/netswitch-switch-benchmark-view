AI2ORBIT SETUP PACK - 27.10.2026

docs/                    End report and setup instructions: PDF, TXT, DOCX; inventory: XLSX
pages-netswitch/         The web suite, every page - put on any static web host, or open menu.html
pages-football-ai-3d/    FootballAI site - open play.html
switch9/                 Switch 9 native C++ engine: source, Windows / Linux / Android builds, README
footballai-android/      FootballAI Android app 1.2.0: APK to install, AAB for Google Play

Start with docs/AI2Orbit-End-Report.pdf - Setup 1 to 9.
The page links in the report open the copy in this pack, on whatever host it is set up on.
Corporate browsers (Talon, Citrix, Edge for Business): open pages-netswitch/corporate.html in them.

AI2ORBIT CO. Network system Pat. pend. Founded in 2018. Copyright 2018-2027. All rights reserved.
